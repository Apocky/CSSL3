# Labyrinth of Apocalypse alpha test-build license

Updated July 27, 2026

This is the End-User License Agreement for the Labyrinth of Apocalypse
v0.1.0-alpha test build, including `LoA.exe` and proprietary files distributed
with it. By extracting or running those files, you accept this agreement. If
you do not accept it, do not run the program and delete the proprietary files.

## 1. Permission to use the test build

Apocky gives you a limited, non-exclusive, non-transferable license to:

- run the test build on personal devices you own or control;
- measure its performance and take screenshots or recordings;
- stream it, review it, and send feedback; and
- keep reasonable backup copies for your own use.

## 2. Restrictions

Unless the law gives you a right that cannot be restricted, you may not:

- redistribute, sell, sublicense, or commercially exploit the proprietary
  test-build files;
- decompile or extract proprietary code, compiled shaders, model data, or
  other protected implementation material;
- use extracted proprietary material in another product without separate
  written permission; or
- remove copyright, license, or attribution notices.

## 3. Separately licensed material

This agreement applies only to files distributed under it. Source code,
specifications, libraries, or other material that displays a separate
open-source or proprietary license remains governed by that license. This
agreement does not take away rights granted by a separate license.

## 4. Privacy and system access

The public build is intended to run without digital rights management, a
rootkit, or a kernel-level anti-cheat driver.

- **Digital rights management**, or DRM, is technology that restricts copying
  or use.
- A **rootkit** is software designed to hide deep system access.
- A **kernel driver** runs with extensive operating-system privileges.

The build creates local diagnostic files and can start a developer interface
on this computer. Read `README.md` before running it. This agreement is not
permission for undisclosed collection or for access to a camera, microphone,
online account, or another device.

## 5. Unfinished software and backups

This is alpha software. It is unfinished and may contain serious bugs,
including bugs that damage or lose data. Back up important files. Do not use
the test build for safety-critical work or where a failure could cause serious
harm.

## 6. No warranty

To the extent allowed by law, the test build is provided “as is,” without
implied warranties of merchantability, fitness for a particular purpose, or
non-infringement. Rights that cannot legally be waived remain in effect.

## 7. Limits on liability

To the extent allowed by law, Apocky’s total liability under this agreement is
limited to the greater of 100 US dollars or the amount you paid for the
affected test build. This limit does not apply where the law does not allow it.

## 8. Feedback

You are not required to provide feedback. If you deliberately send feedback,
you give Apocky a non-exclusive, worldwide, royalty-free license to use it to
develop and improve projects. This does not transfer ownership of unrelated
material or private content you did not choose to submit.

## 9. Ending the license

You may stop using the test build at any time. This license ends if you
materially violate it. When it ends, stop using and delete the proprietary
files covered by it. Terms that logically need to survive, including warranty,
liability, and governing-law terms, continue to apply.

## 10. Governing law

Arizona law governs this agreement without overriding consumer protections
that must apply where you live. Courts in Maricopa County, Arizona have
jurisdiction unless applicable law requires another forum.

## 11. Contact

Email apocky13@gmail.com with `[LoA-LICENSE]` in the subject.

The web copy of this license is available at:
https://www.apocky.com/legal/eula
