# Labyrinth of Apocalypse v0.1.0-alpha

This is an early 64-bit Windows test build. It is unfinished and may contain
serious bugs. The program file, `LoA.exe`, was released on May 3, 2026. The
plain-language files in this ZIP were corrected on July 27, 2026; the program
itself was not rebuilt as part of that correction.

## What this build is

Labyrinth of Apocalypse, shortened to LoA, is a game and engine project. This
build opens a small test room where you can:

- move and look around;
- try several display and material views;
- type a limited set of game requests; and
- save screenshots.

The text panel uses fixed rules to recognize supported requests. It is a game
control, not a conversation with Apocrypha.

Combat, crafting, brewing, spell-casting, the marketplace, online multiplayer,
online accounts, and the complete game are not available in this build.

## Before you open it

`LoA.exe` is not digitally signed. Windows may warn that the publisher is
unknown. A digital signature identifies who signed a program. The SHA-256 file
fingerprint published with this ZIP can show whether the downloaded bytes
changed, but it does not identify a publisher or prove that a program is safe.

Only continue if you understand and accept that distinction. Back up important
files before testing unfinished software.

## How to run it

1. Extract the ZIP into a new folder you control, such as `C:\Games\LoA`.
2. Read `LICENSE.md` and `CONTROLS.md`.
3. Double-click `LoA.exe`, or run `.\LoA.exe` from PowerShell.
4. Press `/` to activate the text line, type a supported request, and press
   Enter.
5. Press Esc to cancel text entry or open the pause menu.

## Files the program may create

The program creates local diagnostic files in a `logs` folder beside
`LoA.exe`. “Diagnostic” means information used to understand performance and
failures. It may also create:

- PNG screenshots in a `snapshots` folder;
- cached files in a `cache` folder; and
- experimental local state in a `.loa` folder under your Windows user folder.

Close the program before deleting its files. You can delete logs and
screenshots when you no longer want them. Back up experimental state before
removing it if you want later runs to retain it.

This ZIP does not contain pre-generated activity logs.

## Local developer connection

The build can start an advanced developer interface at
`127.0.0.1:3001`. The address `127.0.0.1` means this computer only, and `3001`
is the numbered connection point used by the interface. Do not route or expose
that connection to another device or the internet.

Project source uses the name Model Context Protocol, or MCP, for the technical
message format used by this interface. The presence of a named developer
function does not mean the corresponding game feature is complete.

## Network and privacy boundary

The current test-room and fixed text-request rules are intended to work
locally. Online multiplayer, online saves, public sharing, and account features
are not available in this build.

The included `content_manifest.json` is a developer-facing data file. It names
experiments, source locations, and possible later features. A name in that file
is not proof that the feature is running or available. Some optional asset
download settings appear in that file; they are documented as off by default.

Review local logs before sending them to anyone because logs can contain
computer details, file paths, and text entered during a run.

## Words used in the technical files

- **Alpha:** an unfinished test version.
- **Local:** stored or run on this computer.
- **Seed:** a value used to reproduce a generated starting point.
- **Permission:** an explicit allowance for a particular action.
- **Cache:** temporary files kept to avoid repeating work.

More project terms and symbols are explained at:
https://www.apocky.com/words

## Problems and feedback

Feedback is optional.

- Email: apocky13@gmail.com
- Suggested subject: `[LoA-alpha] short summary`
- Public code: https://github.com/Apocky/CSSL3
- Optional support: https://ko-fi.com/oneinfinity
- Optional support: https://www.patreon.com/0ne1nfinity

Do not attach a log or screenshot until you have checked it for private
information.

## License

Read `LICENSE.md` before running the program. Separate source repositories and
files may use their own licenses; the license shown with each source controls
that source.
