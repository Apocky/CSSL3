# Labyrinth of Apocalypse controls

These controls describe the v0.1.0-alpha Windows test build.

- **Available** means the control is expected to work in this build.
- **Unfinished** means the control exists but its result may be incomplete or
  may change.

## Movement

| Key | Action | Status |
|---|---|---|
| W | Move forward | Available |
| A | Move left | Available |
| S | Move backward | Available |
| D | Move right | Available |
| Space | Jump | Available |
| Shift | Sprint while held | Available |
| Ctrl | Crouch while held | Available |
| Mouse | Look around | Available |

The program captures the mouse pointer while the game window is focused.

## Text requests

| Key | Action |
|---|---|
| / | Activate the text line |
| Enter | Submit the current request |
| Esc | Cancel text entry or open the pause menu |
| Backspace | Delete one character |
| Left / Right | Move within the text |
| Home / End | Move to the start or end |
| Up / Down | Browse recent requests |

The text line compares your words with a fixed list of supported game
requests. It is a command interface for the game, not a conversation with
Apocrypha.

Some source files use the words GM, DM, and Coder for experimental in-game
roles:

- **GM** means the local game guide that produces simple on-screen responses.
- **DM** means an experimental route for requests that would change a scene.
- **Coder** means an experimental developer route for proposed code changes.

A technical permission name in the interface does not prove that the
corresponding action is connected or safe. Do not use developer routes unless
you understand their source and current implementation.

## Display modes

| Key | Action | Status |
|---|---|---|
| F1 | Default display | Available |
| F2 | Wireframe view | Available |
| F3 | Surface-direction view | Available |
| F4 | Texture-coordinate grid | Available |
| F5 | Base color without shading | Available |
| F6 | Material-number heat map | Available |
| F7 | Separate light contributions | Unfinished |
| F8 | Light-spectrum debugging view | Unfinished |

These are developer and visual-calibration views. A technical display name is
not a claim that the complete planned renderer is present.

## Screenshots and window controls

| Key | Action | Status |
|---|---|---|
| F9 | Capture 10 frames as PNG images | Available |
| F11 | Turn borderless full-screen on or off | Available |
| F12 | Take one PNG screenshot | Available |
| Tab | Pause and open the menu | Available |

F9 and F12 write images into a `snapshots` folder next to `LoA.exe`.

## Local developer interface

The program can expose an advanced local interface at `127.0.0.1:3001`.
The address `127.0.0.1` means this computer only. Do not route or expose that
connection to another device or the internet.

Project source calls the message format Model Context Protocol, or MCP. It lets
another local program call named developer functions. Some named functions are
unfinished. The interface does not make an unfinished game feature available.

## If a control does not work

Close the program, keep the local logs, and report the exact key, visible
result, and time of the problem. Review logs for private information before
sending them.

Current online documentation:
https://www.apocky.com/docs/keyboard-shortcuts
